<?php

//required so we can access our class Buddy
require 'class.Buddy.inc';

//Creates an object that uses the class Buddy
$buddy = new Buddy;

//assigning values to the variables in the Buddy class
$buddy->buddy_name = 'Bob';
$buddy->buddy_age = 20;
$buddy->buddy_gender = 'Male';

//Displays our information using the display function in the Buddy class.
echo '<h2>Showing Buddy info</h2>';
echo $buddy->display();

//just some spacers
echo "<br>";
echo "<br>";

//Attempt to show protected information
echo "<h2>Protected Information</h2>";
echo "Address: {$buddy->_buddy_address}";

 ?>
